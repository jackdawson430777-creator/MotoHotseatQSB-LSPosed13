# Moto Hotseat QSB LSPosed — Dock height control v1.2

Target package: `com.motorola.launcher3`.

- Keeps the two QSB boolean resource replacements confirmed working on the device.
- Provides a scrollable settings screen with a 40–152 dp slider and an explicit Save button.
- Saves the height in the module app's private preferences; the exported read-only ContentProvider exposes only the integer height to the launcher process.
- Hooks `View.measure` after measurement and uses `setMeasuredDimension()` for the `Hotseat` view, instead of writing the measured-height field directly.

## Build
Use Android Studio with JDK 17 and Android SDK 35, or push the project to GitHub and run **Actions → Build APK → Run workflow**. Install `app-debug.apk`, enable the module in LSPosed, and keep `com.motorola.launcher3` in scope. Open the app, choose a height, tap Save, then force-stop the launcher and return to Home.

This source project has not been compiled or device-tested in this environment. If the settings app still fails to open, capture its crash from Android Settings → Apps → Moto Dock 高度控制 → App info, or send the `FATAL EXCEPTION` section from Logcat. If the slider saves but height does not change, send the LSPosed log after restarting the launcher.
